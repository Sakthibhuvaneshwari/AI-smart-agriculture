/* ============================================
   AI Agricultural Assistant - Main JavaScript
   ============================================ */

// Wait for DOM to load
document.addEventListener('DOMContentLoaded', function() {
    // Initialize AOS Animation
    initAOS();
    
    // Initialize Navbar Scroll Effect
    initNavbar();
    
    // Initialize Mobile Menu
    initMobileMenu();
    
    // Initialize File Upload
    initFileUpload();
    
    // Initialize Form Submissions
    initForms();
    
    // Initialize Dashboard Charts
    initDashboard();
    
    // Initialize Smooth Scroll
    initSmoothScroll();
});

/* ============================================
   AOS Animation Initialization
   ============================================ */
function initAOS() {
    // Check if AOS library is available
    if (typeof AOS !== 'undefined') {
        AOS.init({
            duration: 800,
            easing: 'ease-out-cubic',
            once: true,
            offset: 100,
            delay: 100
        });
    } else {
        // Fallback: Simple fade-in for elements
        const elements = document.querySelectorAll('[data-aos]');
        elements.forEach(el => {
            el.classList.add('aos-animate');
        });
    }
}

/* ============================================
   Navbar Scroll Effect
   ============================================ */
function initNavbar() {
    const navbar = document.querySelector('.navbar');
    
    if (navbar) {
        window.addEventListener('scroll', () => {
            if (window.scrollY > 50) {
                navbar.classList.add('scrolled');
            } else {
                navbar.classList.remove('scrolled');
            }
        });
        
        // Set active nav link based on current page
        setActiveNavLink();
    }
}

function setActiveNavLink() {
    const currentPage = window.location.pathname.split('/').pop() || 'index.html';
    const navLinks = document.querySelectorAll('.nav-link');
    
    navLinks.forEach(link => {
        const href = link.getAttribute('href');
        if (href === currentPage || (currentPage === '' && href === 'index.html')) {
            link.classList.add('active');
        } else {
            link.classList.remove('active');
        }
    });
}

/* ============================================
   Mobile Menu Toggle
   ============================================ */
function initMobileMenu() {
    const navbarToggler = document.querySelector('.navbar-toggler');
    const navbarCollapse = document.querySelector('.navbar-collapse');
    
    if (navbarToggler && navbarCollapse) {
        navbarToggler.addEventListener('click', () => {
            navbarCollapse.classList.toggle('show');
        });
        
        // Close menu when clicking outside
        document.addEventListener('click', (e) => {
            if (!navbarToggler.contains(e.target) && !navbarCollapse.contains(e.target)) {
                navbarCollapse.classList.remove('show');
            }
        });
        
        // Close menu when clicking on a nav link
        const navLinks = navbarCollapse.querySelectorAll('.nav-link');
        navLinks.forEach(link => {
            link.addEventListener('click', () => {
                navbarCollapse.classList.remove('show');
            });
        });
    }
}

/* ============================================
   File Upload with Drag & Drop
   ============================================ */
function initFileUpload() {
    const fileInput = document.getElementById('fileInput');
    const uploadWrapper = document.querySelector('.file-upload-wrapper');
    const imagePreview = document.getElementById('imagePreview');
    const previewContainer = document.querySelector('.preview-container');
    
    if (!fileInput || !uploadWrapper) return;
    
    // Click to upload
    uploadWrapper.addEventListener('click', () => {
        fileInput.click();
    });
    
    // File input change
    fileInput.addEventListener('change', function(e) {
        const file = this.files[0];
        if (file) {
            handleFile(file);
        }
    });
    
    // Drag and drop events
    ['dragenter', 'dragover', 'dragleave', 'drop'].forEach(eventName => {
        uploadWrapper.addEventListener(eventName, preventDefaults, false);
    });
    
    function preventDefaults(e) {
        e.preventDefault();
        e.stopPropagation();
    }
    
    // Drag over effect
    ['dragenter', 'dragover'].forEach(eventName => {
        uploadWrapper.addEventListener(eventName, () => {
            uploadWrapper.classList.add('dragover');
        }, false);
    });
    
    // Drag leave effect
    ['dragleave', 'drop'].forEach(eventName => {
        uploadWrapper.addEventListener(eventName, () => {
            uploadWrapper.classList.remove('dragover');
        }, false);
    });
    
    // Handle dropped file
    uploadWrapper.addEventListener('drop', (e) => {
        const dt = e.dataTransfer;
        const files = dt.files;
        
        if (files.length > 0) {
            fileInput.files = files;
            handleFile(files[0]);
        }
    }, false);
    
    function handleFile(file) {
        // Validate file type
        const validTypes = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
        
        if (!validTypes.includes(file.type)) {
            showAlert('Please upload a valid image file (JPEG, PNG, GIF, or WebP)', 'error');
            return;
        }
        
        // Validate file size (max 10MB)
        if (file.size > 10 * 1024 * 1024) {
            showAlert('File size must be less than 10MB', 'error');
            return;
        }
        
        // Read and preview image
        const reader = new FileReader();
        reader.onload = (e) => {
            if (imagePreview) {
                imagePreview.src = e.target.result;
                imagePreview.style.display = 'block';
            }
            if (previewContainer) {
                previewContainer.style.display = 'block';
            }
            
            // Add pulse animation
            if (imagePreview) {
                imagePreview.classList.add('pulse-animation');
                setTimeout(() => {
                    imagePreview.classList.remove('pulse-animation');
                }, 2000);
            }
            
            showAlert('Image uploaded successfully!', 'success');
        };
        reader.readAsDataURL(file);
    }
}

/* ============================================
   Disease Detection Prediction
   ============================================ */
function predictDisease() {
    const imagePreview = document.getElementById('imagePreview');
    const predictBtn = document.getElementById('predictBtn');
    const resultContainer = document.getElementById('resultContainer');
    const loadingSpinner = document.getElementById('loadingSpinner');
    
    if (!imagePreview || imagePreview.style.display === 'none') {
        showAlert('Please upload an image first', 'error');
        return;
    }
    
    // Show loading
    if (predictBtn) {
        predictBtn.disabled = true;
        predictBtn.innerHTML = '<span class="spinner-border spinner-border-sm me-2"></span>Analyzing...';
    }
    
    if (loadingSpinner) {
        loadingSpinner.style.display = 'block';
    }
    
    // Simulate AI prediction (in real app, this would call an API)
    setTimeout(() => {
        // Mock disease data
        const diseases = [
            {
                name: 'Bacterial Leaf Spot',
                confidence: 94.7,
                causes: [
                    'Xanthomonas campestris bacteria',
                    'Warm, humid weather conditions',
                    'Overhead irrigation',
                    'Crowded plant spacing'
                ],
                treatment: [
                    'Apply copper-based fungicide',
                    'Remove infected leaves',
                    'Improve air circulation',
                    'Avoid overhead watering'
                ],
                prevention: [
                    'Use disease-free seeds',
                    'Rotate crops every 2-3 years',
                    'Maintain proper plant spacing',
                    'Water at soil level'
                ]
            },
            {
                name: 'Powdery Mildew',
                confidence: 91.2,
                causes: [
                    'Fungal infection (Erysiphales)',
                    'High humidity levels',
                    'Poor air circulation',
                    'Temperature variations'
                ],
                treatment: [
                    'Apply neem oil solution',
                    'Use sulfur-based fungicide',
                    'Remove heavily infected leaves',
                    'Apply milk spray (1:9 milk to water)'
                ],
                prevention: [
                    'Ensure good air circulation',
                    'Avoid excessive nitrogen fertilization',
                    'Plant resistant varieties',
                    'Monitor humidity levels'
                ]
            },
            {
                name: 'Healthy Leaf',
                confidence: 98.5,
                causes: [],
                treatment: [
                    'Continue regular care routine',
                    'Maintain proper watering schedule',
                    'Monitor for any changes'
                ],
                prevention: [
                    'Continue preventive measures',
                    'Regular fertilization',
                    'Proper sunlight exposure'
                ]
            }
        ];
        
        // Randomly select a disease for demo
        const randomDisease = diseases[Math.floor(Math.random() * diseases.length)];
        
        // Hide loading
        if (predictBtn) {
            predictBtn.disabled = false;
            predictBtn.innerHTML = '<i class="fas fa-search me-2"></i>Predict Disease';
        }
        
        if (loadingSpinner) {
            loadingSpinner.style.display = 'none';
        }
        
        // Display results
        displayDiseaseResult(randomDisease);
        
    }, 2500); // Simulate 2.5s processing time
}

function displayDiseaseResult(disease) {
    const resultContainer = document.getElementById('resultContainer');
    
    if (!resultContainer) return;
    
    const html = `
        <div class="disease-result" data-aos="fade-up">
            <div class="disease-header">
                <h3 class="disease-name">${disease.name}</h3>
                <span class="confidence-badge">
                    <i class="fas fa-percentage me-1"></i>${disease.confidence}% Confidence
                </span>
            </div>
            <div class="disease-body">
                ${disease.causes.length > 0 ? `
                <div class="info-section">
                    <h5><i class="-circle"></i>fas fa-question Causes</h5>
                    <ul>
                        ${disease.causes.map(cause => `<li>${cause}</li>`).join('')}
                    </ul>
                </div>
                ` : ''}
                
                <div class="info-section">
                    <h5><i class="fas fa-stethoscope"></i> Treatment</h5>
                    <ul>
                        ${disease.treatment.map(treat => `<li>${treat}</li>`).join('')}
                    </ul>
                </div>
                
                <div class="info-section">
                    <h5><i class="fas fa-shield-alt"></i> Prevention Tips</h5>
                    <ul>
                        ${disease.prevention.map(tip => `<li>${tip}</li>`).join('')}
                    </ul>
                </div>
            </div>
        </div>
    `;
    
    resultContainer.innerHTML = html;
    
    // Re-init AOS for new content
    if (typeof AOS !== 'undefined') {
        AOS.refresh();
    }
    
    // Scroll to result
    resultContainer.scrollIntoView({ behavior: 'smooth', block: 'start' });
}

/* ============================================
   Crop Recommendation
   ============================================ */
function recommendCrop() {
    const soilType = document.getElementById('soilType');
    const season = document.getElementById('season');
    const location = document.getElementById('location');
    const resultCard = document.getElementById('cropResult');
    
    if (!soilType || !season || !resultCard) return;
    
    // Validate inputs
    if (!soilType.value || !season.value) {
        showAlert('Please fill in all required fields', 'error');
        return;
    }
    
    // Mock crop recommendations based on soil and season
    const crops = {
        'loamy': {
            'kharif': { name: 'Rice', description: 'Loamy soil is perfect for rice cultivation as it retains water well.', duration: '120-150 days', yield: '3-4 tons/hectare' },
            'rabi': { name: 'Wheat', description: 'Wheat grows excellently in loamy soil during rabi season.', duration: '120-140 days', yield: '2.5-3.5 tons/hectare' },
            'zaid': { name: 'Maize', description: 'Maize thrives in loamy soil with good drainage.', duration: '90-120 days', yield: '4-5 tons/hectare' }
        },
        'clay': {
            'kharif': { name: 'Sugarcane', description: 'Clay soil retains moisture well, ideal for sugarcane.', duration: '12-18 months', yield: '50-80 tons/hectare' },
            'rabi': { name: 'Gram', description: 'Gram grows well in clay soil with good water retention.', duration: '90-120 days', yield: '1.5-2 tons/hectare' },
            'zaid': { name: 'Vegetables', description: 'Various vegetables can be grown in clay soil.', duration: '60-90 days', yield: 'Varies' }
        },
        'sandy': {
            'kharif': { name: 'Groundnut', description: 'Sandy soil is perfect for groundnut cultivation.', duration: '120-140 days', yield: '1.5-2 tons/hectare' },
            'rabi': { name: 'Mustard', description: 'Mustard grows well in sandy soil with good drainage.', duration: '100-120 days', yield: '1-1.5 tons/hectare' },
            'zaid': { name: 'Watermelon', description: 'Watermelon thrives in sandy soil with proper irrigation.', duration: '80-100 days', yield: '20-30 tons/hectare' }
        },
        'silt': {
            'kharif': { name: 'Cotton', description: 'Silt soil is excellent for cotton cultivation.', duration: '150-180 days', yield: '1.5-2 tons/hectare' },
            'rabi': { name: 'Barley', description: 'Barley grows well in silt soil.', duration: '90-120 days', yield: '2-3 tons/hectare' },
            'zaid': { name: 'Soybean', description: 'Soybean can be cultivated in silt soil.', duration: '90-110 days', yield: '1.5-2 tons/hectare' }
        },
        'peaty': {
            'kharif': { name: 'Rice', description: 'Peaty soil can support rice cultivation with proper management.', duration: '120-150 days', yield: '2.5-3.5 tons/hectare' },
            'rabi': { name: 'Peas', description: 'Peas grow well in peaty soil.', duration: '60-90 days', yield: '1-1.5 tons/hectare' },
            'zaid': { name: 'Leafy Vegetables', description: 'Leafy vegetables thrive in peaty soil.', duration: '30-60 days', yield: 'Varies' }
        }
    };
    
    const location_val = location ? location.value : 'Unknown';
    const selectedCrop = crops[soilType.value]?.[season.value] || { 
        name: 'Consult Expert', 
        description: 'Please consult with an agricultural expert for specific recommendations.',
        duration: 'N/A',
        yield: 'N/A'
    };
    
    // Display result
    resultCard.innerHTML = `
        <div class="result-card" data-aos="fade-up">
            <div class="text-center mb-4">
                <div class="feature-icon d-inline-flex">
                    <i class="fas fa-seedling"></i>
                </div>
                <h3 class="mt-3">Recommended Crop: ${selectedCrop.name}</h3>
                <p class="mb-3">${selectedCrop.description}</p>
            </div>
            <div class="row">
                <div class="col-md-6 mb-3">
                    <div class="info-section">
                        <h5><i class="fas fa-calendar-alt"></i> Growing Duration</h5>
                        <p class="mb-0">${selectedCrop.duration}</p>
                    </div>
                </div>
                <div class="col-md-6 mb-3">
                    <div class="info-section">
                        <h5><i class="fas fa-chart-line"></i> Expected Yield</h5>
                        <p class="mb-0">${selectedCrop.yield}</p>
                    </div>
                </div>
            </div>
            <div class="info-section mt-3">
                <h5><i class="fas fa-map-marker-alt"></i> Location</h5>
                <p class="mb-0">${location_val}</p>
            </div>
        </div>
    `;
    
    // Scroll to result
    resultCard.scrollIntoView({ behavior: 'smooth', block: 'start' });
    
    if (typeof AOS !== 'undefined') {
        AOS.refresh();
    }
}

/* ============================================
   Weather Information
   ============================================ */
function getWeather() {
    const cityInput = document.getElementById('cityInput');
    const weatherResult = document.getElementById('weatherResult');
    
    if (!cityInput || !weatherResult) return;
    
    const city = cityInput.value.trim();
    
    if (!city) {
        showAlert('Please enter a city name', 'error');
        return;
    }
    
    // Mock weather data (in real app, call weather API)
    const weatherData = {
        'delhi': { temp: 32, humidity: 45, rain: '10%', condition: 'sunny', suggestion: 'Good day for harvesting. Ensure irrigation in afternoon.' },
        'mumbai': { temp: 28, humidity: 75, rain: '60%', condition: 'rainy', suggestion: 'Rain expected. Avoid spraying pesticides. Check drainage.' },
        'bangalore': { temp: 24, humidity: 65, rain: '30%', condition: 'cloudy', suggestion: 'Ideal weather for planting. Monitor humidity levels.' },
        'chennai': { temp: 35, humidity: 55, rain: '5%', condition: 'sunny', suggestion: 'High temperature. Provide shade to sensitive crops.' },
        'kolkata': { temp: 30, humidity: 70, rain: '45%', condition: 'cloudy', suggestion: 'Humid conditions. Watch for fungal diseases.' },
        'hyderabad': { temp: 29, humidity: 50, rain: '20%', condition: 'partly-cloudy', suggestion: 'Good weather for field work. Continue regular irrigation.' }
    };
    
    const normalizedCity = city.toLowerCase();
    const weather = weatherData[normalizedCity] || {
        temp: Math.floor(Math.random() * 15) + 20,
        humidity: Math.floor(Math.random() * 40) + 40,
        rain: Math.floor(Math.random() * 50) + 10 + '%',
        condition: ['sunny', 'cloudy', 'rainy', 'partly-cloudy'][Math.floor(Math.random() * 4)],
        suggestion: 'General farming activities can proceed. Monitor local weather updates.'
    };
    
    const weatherIcons = {
        'sunny': 'fa-sun',
        'cloudy': 'fa-cloud',
        'rainy': 'fa-cloud-rain',
        'partly-cloudy': 'fa-cloud-sun'
    };
    
    weatherResult.innerHTML = `
        <div class="weather-card" data-aos="fade-up">
            <div class="weather-icon">
                <i class="fas ${weatherIcons[weather.condition]}"></i>
            </div>
            <h2 class="weather-temp">${weather.temp}°C</h2>
            <p class="mb-0">${city.charAt(0).toUpperCase() + city.slice(1)}</p>
            
            <div class="weather-details">
                <div class="weather-detail">
                    <i class="fas fa-tint"></i>
                    <p class="mb-0">${weather.humidity}%</p>
                    <small>Humidity</small>
                </div>
                <div class="weather-detail">
                    <i class="fas fa-cloud-rain"></i>
                    <p class="mb-0">${weather.rain}</p>
                    <small>Rain</small>
                </div>
            </div>
            
            <div class="farming-suggestion">
                <h5><i class="fas fa-lightbulb me-2"></i>Farming Suggestion</h5>
                <p class="mb-0">${weather.suggestion}</p>
            </div>
        </div>
    `;
    
    weatherResult.scrollIntoView({ behavior: 'smooth', block: 'start' });
    
    if (typeof AOS !== 'undefined') {
        AOS.refresh();
    }
}

/* ============================================
   Fertilizer Recommendation
   ============================================ */
function recommendFertilizer() {
    const nitrogen = document.getElementById('nitrogen');
    const phosphorus = document.getElementById('phosphorus');
    const potassium = document.getElementById('potassium');
    const resultCard = document.getElementById('fertilizerResult');
    
    if (!nitrogen || !phosphorus || !potassium || !resultCard) return;
    
    const n = parseFloat(nitrogen.value) || 0;
    const p = parseFloat(phosphorus.value) || 0;
    const k = parseFloat(potassium.value) || 0;
    
    if (n === 0 && p === 0 && k === 0) {
        showAlert('Please enter at least one NPK value', 'error');
        return;
    }
    
    // Determine fertilizer recommendation based on NPK values
    let fertilizer, usage, tips;
    
    if (n < 20 && p < 20 && k < 20) {
        fertilizer = 'Balanced NPK Fertilizer (10-10-10)';
        usage = 'Apply 100-120 kg/acre';
        tips = [
            'Use for general crop health',
            'Apply at planting time',
            'Can be used for most crops'
        ];
    } else if (n > 40 && p < 20 && k < 20) {
        fertilizer = 'Urea (46% Nitrogen)';
        usage = 'Apply 60-80 kg/acre';
        tips = [
            'High nitrogen for leafy growth',
            'Split application recommended',
            'Avoid direct contact with leaves'
        ];
    } else if (n < 20 && p > 40 && k < 20) {
        fertilizer = 'DAP (Di-Ammonium Phosphate)';
        usage = 'Apply 80-100 kg/acre';
        tips = [
            'High phosphorus for root development',
            'Apply at planting stage',
            'Good for flowering plants'
        ];
    } else if (n < 20 && p < 20 && k > 40) {
        fertilizer = 'Muriate of Potash (MOP)';
        usage = 'Apply 40-60 kg/acre';
        tips = [
            'High potassium for disease resistance',
            'Apply during fruiting stage',
            'Improves crop quality'
        ];
    } else if (n > 30 && p > 30 && k < 20) {
        fertilizer = 'NPK 20-20-0';
        usage = 'Apply 80-100 kg/acre';
        tips = [
            'Balanced nitrogen and phosphorus',
            'Good for vegetative growth',
            'Ideal for kharif crops'
        ];
    } else if (n > 30 && p > 30 && k > 30) {
        fertilizer = 'NPK 20-20-20 (Water Soluble)';
        usage = 'Apply 5-10 kg/acre via drip';
        tips = [
            'Complete nutrition',
            'Can be used for fertigation',
            'Suitable for vegetables'
        ];
    } else {
        fertilizer = 'Custom NPK Mix';
        usage = `Apply based on soil test results: N-${n}, P-${p}, K-${k}`;
        tips = [
            'Follow soil test recommendations',
            'Consider crop requirements',
            'Consult agricultural expert'
        ];
    }
    
    resultCard.innerHTML = `
        <div class="result-card" data-aos="fade-up">
            <div class="text-center mb-4">
                <div class="card-icon d-inline-flex">
                    <i class="fas fa-flask"></i>
                </div>
                <h3 class="mt-3">Recommended Fertilizer</h3>
                <h4 class="text-primary-custom">${fertilizer}</h4>
            </div>
            
            <div class="row mb-4">
                <div class="col-md-4 mb-3">
                    <div class="info-section">
                        <h5><i class="fas fa-leaf text-success"></i> Nitrogen (N)</h5>
                        <p class="mb-0 fw-bold">${n} ppm</p>
                    </div>
                </div>
                <div class="col-md-4 mb-3">
                    <div class="info-section">
                        <h5><i class="fas fa-fire text-danger"></i> Phosphorus (P)</h5>
                        <p class="mb-0 fw-bold">${p} ppm</p>
                    </div>
                </div>
                <div class="col-md-4 mb-3">
                    <div class="info-section">
                        <h5><i class="fas fa-tint text-info"></i> Potassium (K)</h5>
                        <p class="mb-0 fw-bold">${k} ppm</p>
                    </div>
                </div>
            </div>
            
            <div class="info-section">
                <h5><i class="fas fa-ruler-combined"></i> Recommended Usage</h5>
                <p class="text-primary-custom fw-bold">${usage}</p>
            </div>
            
            <div class="info-section">
                <h5><i class="fas fa-info-circle"></i> Application Tips</h5>
                <ul>
                    ${tips.map(tip => `<li>${tip}</li>`).join('')}
                </ul>
            </div>
        </div>
    `;
    
    resultCard.scrollIntoView({ behavior: 'smooth', block: 'start' });
    
    if (typeof AOS !== 'undefined') {
        AOS.refresh();
    }
}

/* ============================================
   Dashboard Charts
   ============================================ */
function initDashboard() {
    // Check if we're on dashboard page
    if (!document.getElementById('diseaseChart')) return;
    
    // Disease Detection Chart
    const diseaseCtx = document.getElementById('diseaseChart');
    if (diseaseCtx) {
        new Chart(diseaseCtx, {
            type: 'doughnut',
            data: {
                labels: ['Healthy', 'Bacterial', 'Fungal', 'Viral'],
                datasets: [{
                    data: [45, 25, 20, 10],
                    backgroundColor: [
                        '#4CAF50',
                        '#FF9800',
                        '#F44336',
                        '#9C27B0'
                    ],
                    borderWidth: 0
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        position: 'bottom'
                    }
                }
            }
        });
    }
    
    // Crop Distribution Chart
    const cropCtx = document.getElementById('cropChart');
    if (cropCtx) {
        new Chart(cropCtx, {
            type: 'bar',
            data: {
                labels: ['Rice', 'Wheat', 'Cotton', 'Sugarcane', 'Vegetables'],
                datasets: [{
                    label: 'Recommended Crops',
                    data: [30, 25, 20, 15, 10],
                    backgroundColor: [
                        'rgba(46, 125, 50, 0.8)',
                        'rgba(129, 199, 132, 0.8)',
                        'rgba(255, 193, 7, 0.8)',
                        'rgba(255, 152, 0, 0.8)',
                        'rgba(33, 150, 243, 0.8)'
                    ],
                    borderRadius: 8
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        display: false
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
    }
    
    // Monthly Activity Chart
    const activityCtx = document.getElementById('activityChart');
    if (activityCtx) {
        new Chart(activityCtx, {
            type: 'line',
            data: {
                labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
                datasets: [{
                    label: 'Disease Checks',
                    data: [12, 19, 15, 25, 22, 30],
                    borderColor: '#2E7D32',
                    backgroundColor: 'rgba(46, 125, 50, 0.1)',
                    fill: true,
                    tension: 0.4
                }, {
                    label: 'Crop Recommendations',
                    data: [8, 12, 18, 22, 20, 28],
                    borderColor: '#FFC107',
                    backgroundColor: 'rgba(255, 193, 7, 0.1)',
                    fill: true,
                    tension: 0.4
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        position: 'top'
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
    }
}

/* ============================================
   Form Submissions
   ============================================ */
function initForms() {
    // Disease Detection Form
    const diseaseForm = document.getElementById('diseaseForm');
    if (diseaseForm) {
        diseaseForm.addEventListener('submit', (e) => {
            e.preventDefault();
            predictDisease();
        });
    }
    
    // Crop Recommendation Form
    const cropForm = document.getElementById('cropForm');
    if (cropForm) {
        cropForm.addEventListener('submit', (e) => {
            e.preventDefault();
            recommendCrop();
        });
    }
    
    // Weather Form
    const weatherForm = document.getElementById('weatherForm');
    if (weatherForm) {
        weatherForm.addEventListener('submit', (e) => {
            e.preventDefault();
            getWeather();
        });
        
        // Allow Enter key to submit
        const cityInput = document.getElementById('cityInput');
        if (cityInput) {
            cityInput.addEventListener('keypress', (e) => {
                if (e.key === 'Enter') {
                    e.preventDefault();
                    getWeather();
                }
            });
        }
    }
    
    // Fertilizer Form
    const fertilizerForm = document.getElementById('fertilizerForm');
    if (fertilizerForm) {
        fertilizerForm.addEventListener('submit', (e) => {
            e.preventDefault();
            recommendFertilizer();
        });
    }
    
    // Contact Form
    const contactForm = document.getElementById('contactForm');
    if (contactForm) {
        contactForm.addEventListener('submit', (e) => {
            e.preventDefault();
            
            // Get form values
            const name = document.getElementById('name')?.value;
            const email = document.getElementById('email')?.value;
            const message = document.getElementById('message')?.value;
            
            if (!name || !email || !message) {
                showAlert('Please fill in all fields', 'error');
                return;
            }
            
            // Simulate form submission
            showAlert('Thank you for your message! We will get back to you soon.', 'success');
            contactForm.reset();
        });
    }
}

/* ============================================
   Smooth Scroll
   ============================================ */
function initSmoothScroll() {
    const links = document.querySelectorAll('a[href^="#"]');
    
    links.forEach(link => {
        link.addEventListener('click', function(e) {
            const targetId = this.getAttribute('href');
            
            if (targetId === '#') return;
            
            const target = document.querySelector(targetId);
            
            if (target) {
                e.preventDefault();
                
                target.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
                
                // Update URL without scrolling
                history.pushState(null, null, targetId);
            }
        });
    });
}

/* ============================================
   Alert/Notification System
   ============================================ */
function showAlert(message, type = 'info') {
    // Remove existing alerts
    const existingAlert = document.querySelector('.custom-alert');
    if (existingAlert) {
        existingAlert.remove();
    }
    
    // Create alert element
    const alert = document.createElement('div');
    alert.className = `custom-alert alert alert-${type === 'error' ? 'danger' : type} alert-dismissible fade show`;
    alert.setAttribute('role', 'alert');
    alert.style.cssText = `
        position: fixed;
        top: 100px;
        right: 20px;
        z-index: 9999;
        max-width: 400px;
        box-shadow: 0 4px 12px rgba(0,0,0,0.15);
        animation: slideInRight 0.3s ease-out;
    `;
    
    alert.innerHTML = `
        <i class="fas fa-${type === 'success' ? 'check-circle' : type === 'error' ? 'exclamation-circle' : 'info-circle'} me-2"></i>
        ${message}
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    `;
    
    // Add to body
    document.body.appendChild(alert);
    
    // Auto remove after 5 seconds
    setTimeout(() => {
        alert.remove();
    }, 5000);
}

// Add slideInRight animation
const style = document.createElement('style');
style.textContent = `
    @keyframes slideInRight {
        from {
            opacity: 0;
            transform: translateX(100px);
        }
        to {
            opacity: 1;
            transform: translateX(0);
        }
    }
`;
document.head.appendChild(style);

/* ============================================
   Utility Functions
   ============================================ */

// Format number with commas
function formatNumber(num) {
    return num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
}

// Debounce function
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

// Export functions for global use
window.predictDisease = predictDisease;
window.recommendCrop = recommendCrop;
window.getWeather = getWeather;
window.recommendFertilizer = recommendFertilizer;
window.showAlert = showAlert;
